export 'package:flutter_news_example_api/client.dart'
    show ArticleResponse, RelatedArticlesResponse;

export 'src/article_repository.dart';
